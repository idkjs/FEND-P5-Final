PV Search - Udacity Neighborhood Map Project

Search for a business or type of business by typing in the search box. Use the Hotels and Restaurant buttons for a quick search.

Click on the list result or the a map market to learn more about that business.

Attribution.
http://knockoutjs.com/
https://developers.google.com/maps/?hl=en
https://discussions.udacity.com/c/nd001-project-5-neighborhood-map-project
https://discussions.udacity.com/users/karol/badges
https://stackoverflow.com
https://firebase.com
https://bootstrap.com
https://discussions.udacity.com/t/handling-google-maps-in-async-and-fallback/34282
https://github.com/IronSummitMedia/startbootstrap-simple-sidebar
Start Bootstrap - Simple Sidebar HTML Template (http://startbootstrap.com)