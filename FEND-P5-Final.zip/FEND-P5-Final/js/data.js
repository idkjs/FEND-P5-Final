
var localPlaces = [
  {
    name: 'MATELEC',
    latLng: {lat: 18.5157325, lng: -72.2931357},
    accountid: null,
    heading: null,
    phoneNumber: null,
    website: null
  },
  
  {
    name: 'Thompson Electronics S.A.',
    latLng: {lat: 18.5140218, lng: -72.2919172},
    accountid: null,
    heading: null,
    phoneNumber: null,
    website: null
  },
  
  {
    name: 'Pages Jaunes Haiti',
    latLng: {lat: 18.511007, lng: -72.2911917},
    accountid: null,
    heading: null,
    phoneNumber: null,
    website: null
      },

  {
    name: 'Marie de Petion-Ville',
    latLng: {lat: 18.5098571, lng: -72.2882233},
    accountid: null,
    heading: null,
    phoneNumber: null,
    website: null
  },
  
  {
    name: 'La Lorraine Boutique Hotel',
    latLng: {lat: 18.5123482, lng: -72.2918561},
    accountid: null,
    heading: null,
    phoneNumber: null,
    website: null
      },
  
  {
    name: 'Maison Acra',
    latLng: {lat: 18.5127402, lng: -72.2886953},
    accountid: null,
    heading: null,
    phoneNumber: null,
    website: null
      }
]
